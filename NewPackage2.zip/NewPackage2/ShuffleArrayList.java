package NewPackage2;
import java.util.*;
public class ShuffleArrayList 
{
public static void main(String[]args) {
			List<String> list_Strings=new ArrayList<String>();
			list_Strings.add("White");
			list_Strings.add("Black");
			list_Strings.add("pink");
			list_Strings.add("orange");
			list_Strings.add("Blue");
			System.out.println("list before shuffling:"+list_Strings);
			Collections.shuffle(list_Strings);
			System.out.println("list after shuffling :"+list_Strings);
			
			
			}
}
