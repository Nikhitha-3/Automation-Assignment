package NewPackage2;
import java.util.LinkedList;
import java.util.Iterator;
public class IterateElementsLinkedList {
	public static void main(String[]args) {
		LinkedList<String> l_list =new LinkedList<String>();
		l_list.add("StrawBerry");
		l_list.add("Mango");
		l_list.add("PineApple");
		l_list.add("WaterMelon");
		l_list.add("Apple");
		Iterator p =l_list.listIterator(1);
		
		
		while(p.hasNext()) {
			System.out.println(p.next());
		}
		}
	}


