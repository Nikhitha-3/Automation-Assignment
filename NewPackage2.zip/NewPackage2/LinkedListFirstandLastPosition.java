package NewPackage2;
import java.util.LinkedList;
public class LinkedListFirstandLastPosition {
	public static void main(String []args) {
	LinkedList<String> l_list= new LinkedList<String>();
	l_list.add("Nikhitha");
	l_list.add("Bhavitha");
	l_list.add("Supraja");
	l_list.add("Venkat");
	System.out.println("original linked list:" +l_list);
	l_list.addFirst("Nani");
	l_list.addLast("Ammu");
	System.out.println("Final linked list:" +l_list);

}
}
