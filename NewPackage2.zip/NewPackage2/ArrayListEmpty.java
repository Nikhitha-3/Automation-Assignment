package NewPackage2;
import java.util.*;
public class ArrayListEmpty {
	public static void main(String[]args)
	{
		ArrayList myArrayList=new ArrayList();
		if(myArrayList.isEmpty())
		{
			System.out.println("The ArrayList is empty");
		}
		else
		{
			System.out.println("The ArrayList is not empty");
			
		}
	}

}

