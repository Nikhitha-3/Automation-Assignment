package NewPackage2;
import java.util.*;
public class ColorsInArrayList {
	public static void main(String[]args) {
		ArrayList<String> list=new ArrayList<String>();
		list.add("White");
		list.add("Black");
		list.add("pink");
		list.add("orange");
		list.add("Blue");
		
		
		Iterator itr =list.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
						
	}

}
