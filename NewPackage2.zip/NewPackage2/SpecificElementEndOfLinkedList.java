package NewPackage2;
import java.util.LinkedList;
public class SpecificElementEndOfLinkedList {
	public static void main(String[]args) {
		LinkedList<String>l_list=new LinkedList<String>();
		l_list.add("Apple");
		l_list.add("One plus");
		l_list.add("Oppo");
		l_list.add("Realme");
		l_list.add("Vivo");
		
		System.out.println("The linked list: "+l_list);
		
	}

}
