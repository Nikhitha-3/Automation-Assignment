package NewPackage2;
import java.util.LinkedList;
import java.util.Iterator;
public class LinkedListInReverseOrder {
	public static void main(String[]args) {
		LinkedList<String> l_list=new LinkedList <String>();
		l_list.add("One");
		l_list.add("Two");
		l_list.add("Three");
		l_list.add("Four");
		l_list.add("Five");
		
		
		System.out.println("Original linked list : " +l_list);
		
		Iterator it =l_list.descendingIterator();
		System.out.println("Elemets in reverse order:");
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		
		
	}

}
