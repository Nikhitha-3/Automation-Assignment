package NewPackage2;
import java.util.*;
public class ReverseArrayList {
	public static void main(String[]args) {
		ArrayList<String>arrlist=new ArrayList<String>();
		arrlist.add("Nikhitha");
		arrlist.add("Ammu");
		arrlist.add("bhavi");
		arrlist.add("sari");
		System.out.println("Before Reverse ArrayList : ");
		
		System.out.println(arrlist);
		Collections.reverse(arrlist);
		
		System.out.println("After Reverse ArrayList : ");
		System.out.println(arrlist);
		
		
		
		
		
		
	}

}
